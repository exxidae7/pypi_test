from setuptools import setup, find_packages

setup(
    name='my_package_for_wow_ai',
    version='0.0.1',
    description='A simple package to add two numbers',
    author='cuong',
    author_email='your.email@example.com',
    packages=find_packages(),
)